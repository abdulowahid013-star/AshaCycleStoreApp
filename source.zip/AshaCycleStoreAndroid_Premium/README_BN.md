# Asha Cycle Store — Offline Business App MVP v1.0

## Included modules
- Premium Navy + White Compose UI; Bengali/English switch
- Dashboard: today's sales, total receivables, cash balance, stock units, low-stock list
- POS memo: select saved products, multiple lines, quantity, price, discount, received and due
- Automatic stock deduction on saved sales; insufficient stock is blocked
- Product catalogue: add product, category, buy/sell price, opening stock, low-stock threshold; manual stock adjustment upward
- Purchase entry: select product, quantity, unit cost, supplier, amount paid; purchase increases stock
- Customer due collection: outstanding customers listed; collection reduces due
- Expense entry
- Reports: sales, cost of goods sold, gross profit, expenses, estimated net profit, cash and customer-wise due
- A4 PDF memo sharing
- JSON data backup export using Android share sheet (can manually upload to Google Drive)
- Offline local data persistence; VAT not included; BDT currency

## Important accounting behaviour
- Credit sales do not increase cash; only received amount does.
- Due collections reduce customer receivable and increase cash, not sales.
- Purchases add stock; only the paid portion reduces cash.
- Expenses reduce cash and are subtracted from gross profit in the estimated net profit report.
- Sales reduce stock at memo save time.

## Current limitations — do not use as final audited accounting software yet
- Data is stored in app-private local preferences as JSON, not encrypted Room database.
- Backup export exists, but in-app restore/import and automatic Google Drive sync are not implemented.
- No PIN lock, audit log, memo edit/cancel, returns/refunds, supplier payable ledger, bank account separation, date filters, XLSX export, 80mm PDF, or Bluetooth printer integration.
- Customer matching is by exact entered name; there is no customer ID / auto-merge.
- Purchase cost is recorded on purchase entry, but the product's default buy price is not automatically updated.
- Cash balance is a simplified all-time calculation and assumes zero opening balance.
- Report is all-time, not date-filtered. Net profit is estimated from recorded sales cost and expenses.
- No migration/import from prior Excel records.
- This code has not been built or end-to-end tested on an Android device in this environment. Verify calculations and take backups before real business use.

## Build
1. Extract the ZIP.
2. Open the extracted project folder in Android Studio.
3. Use JDK 17 and Android SDK 35.
4. Wait for Gradle Sync.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).

Package ID: `com.ashacyclestore.app`
Minimum Android: 8.0 (API 26)

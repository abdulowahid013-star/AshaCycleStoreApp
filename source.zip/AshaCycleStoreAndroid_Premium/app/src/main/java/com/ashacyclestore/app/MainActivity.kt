package com.ashacyclestore.app

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.content.FileProvider
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF14283F)
private val Navy2 = Color(0xFF203B59)
private val Canvas = Color(0xFFF4F6F9)
private val Muted = Color(0xFF778397)
private val Green = Color(0xFF16865B)
private fun today() = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
private fun money(v: Double) = "৳ " + String.format(Locale.US, "%,.2f", v)

data class Product(val id: Long, val name: String, val category: String, val buy: Double, val sell: Double, val stock: Int, val min: Int)
data class Line(val productId: Long, val name: String, val qty: Int, val price: Double, val cost: Double) {
    val total get() = qty * price
}
data class Sale(val id: Long, val date: String, val customer: String, val mobile: String, val lines: List<Line>, val discount: Double, val paid: Double) {
    val subtotal get() = lines.sumOf { it.total }
    val total get() = (subtotal - discount).coerceAtLeast(0.0)
    val due get() = (total - paid).coerceAtLeast(0.0)
    val profit get() = total - lines.sumOf { it.qty * it.cost }
}
data class Purchase(val date: String, val supplier: String, val total: Double, val paid: Double, val note: String)
data class Collection(val date: String, val customer: String, val amount: Double, val note: String)
data class Expense(val date: String, val category: String, val amount: Double, val note: String)

data class StoreData(
    val products: List<Product> = emptyList(), val sales: List<Sale> = emptyList(),
    val purchases: List<Purchase> = emptyList(), val collections: List<Collection> = emptyList(),
    val expenses: List<Expense> = emptyList(), val nextId: Long = 1
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AshaApp(this) }
    }
}

@Composable
fun AshaApp(context: Context) {
    var lang by remember { mutableStateOf("বাংলা") }
    var tab by remember { mutableIntStateOf(0) }
    var data by remember { mutableStateOf(loadData(context)) }
    val bn = lang == "বাংলা"
    fun update(d: StoreData) { data = d; saveData(context, d) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Green, background = Canvas, surface = Color.White, onPrimary = Color.White)) {
        Scaffold(containerColor = Canvas, bottomBar = {
            NavigationBar(containerColor = Color.White) {
                val labels = if (bn) listOf("হোম", "মেমো", "পণ্য", "আরও") else listOf("Home", "Memo", "Products", "More")
                val icons = listOf(Icons.Default.Dashboard, Icons.Default.ReceiptLong, Icons.Default.Inventory2, Icons.Default.Menu)
                labels.forEachIndexed { i, label -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icons[i], null) }, label = { Text(label, fontSize = 10.sp) }) }
            }
        }) { pad ->
            Box(Modifier.padding(pad)) {
                when(tab) {
                    0 -> DashboardScreen(data, bn, lang, { lang = it }, { tab = 1 })
                    1 -> PosScreen(data, bn, onSave = { sale ->
                        val updatedProducts = data.products.map { p ->
                            val sold = sale.lines.filter { it.productId == p.id }.sumOf { it.qty }
                            p.copy(stock = p.stock - sold)
                        }
                        update(data.copy(products = updatedProducts, sales = listOf(sale) + data.sales, nextId = data.nextId + 1))
                        tab = 0
                    })
                    2 -> ProductsScreen(data, bn, onAdd = { p -> update(data.copy(products = data.products + p, nextId = data.nextId + 1)) },
                        onUpdate = { p -> update(data.copy(products = data.products.map { if (it.id == p.id) p else it })) })
                    else -> MoreScreen(data, bn,
                        onPurchase = { p -> update(data.copy(products = data.products.map { x -> if (x.id == p.first) x.copy(stock = x.stock + p.second) else x }, purchases = listOf(p.third) + data.purchases)) },
                        onCollection = { c -> update(data.copy(collections = listOf(c) + data.collections)) },
                        onExpense = { e -> update(data.copy(expenses = listOf(e) + data.expenses)) },
                        onBackup = { shareBackup(context, data) },
                        onPdf = { sale -> shareMemoPdf(context, sale) })
                }
            }
        }
    }
}

@Composable
fun DashboardScreen(d: StoreData, bn: Boolean, lang: String, setLang: (String)->Unit, newSale: ()->Unit) {
    val salesToday = d.sales.filter { it.date == today() }
    val todaySales = salesToday.sumOf { it.total }
    val dueByCustomer = customerDues(d)
    val receivable = dueByCustomer.values.sum()
    val cash = d.sales.sumOf { it.paid } + d.collections.sumOf { it.amount } - d.purchases.sumOf { it.paid } - d.expenses.sumOf { it.amount }
    val stockUnits = d.products.sumOf { it.stock }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = Navy, shape = RoundedCornerShape(14.dp), modifier = Modifier.size(46.dp)) { Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.DirectionsBike, null, tint = Color.White, modifier = Modifier.size(28.dp)) } }
                    Spacer(Modifier.width(10.dp))
                    Column { Text("ASHA CYCLE STORE", color = Navy, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp); Text(if (bn) "বিজনেস ম্যানেজমেন্ট" else "BUSINESS MANAGEMENT", color = Muted, fontSize = 9.sp) }
                }
                var open by remember { mutableStateOf(false) }
                Box { TextButton(onClick = { open = true }) { Text("$lang ▾", color = Navy) }; DropdownMenu(open, { open = false }) {
                    DropdownMenuItem(text = { Text("বাংলা") }, onClick = { setLang("বাংলা"); open = false })
                    DropdownMenuItem(text = { Text("English") }, onClick = { setLang("English"); open = false })
                } }
            }
        }
        item {
            Surface(color = Navy, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(if (bn) "আপনার ব্যবসা, এক নজরে" else "Your business at a glance", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("Nimitala Fakir Para, Chapai Nawabganj", color = Color(0xFFB9C8D8), fontSize = 11.sp)
                    Text(if (bn) "অফলাইন • BDT ৳ • VAT বন্ধ" else "Offline • BDT ৳ • VAT disabled", color = Color(0xFFB9C8D8), fontSize = 10.sp)
                }
            }
        }
        item {
            Text(if (bn) "ব্যবসার সারাংশ" else "Business Overview", color = Navy, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Metric(if (bn) "আজকের বিক্রি" else "Today's Sales", money(todaySales), Icons.Default.TrendingUp, Modifier.weight(1f))
                Metric(if (bn) "মোট পাওনা" else "Receivables", money(receivable), Icons.Default.Groups, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Metric(if (bn) "ক্যাশ ব্যালেন্স" else "Cash Balance", money(cash), Icons.Default.Payments, Modifier.weight(1f))
                Metric(if (bn) "স্টক ইউনিট" else "Stock Units", stockUnits.toString(), Icons.Default.Inventory2, Modifier.weight(1f))
            }
        }
        item { Button(onClick = newSale, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp)) { Icon(Icons.Default.AddShoppingCart, null); Spacer(Modifier.width(7.dp)); Text(if (bn) "নতুন মেমো তৈরি করুন" else "Create New Memo") } }
        item { Text(if (bn) "কম স্টকের পণ্য" else "Low Stock", color = Navy, fontWeight = FontWeight.Bold) }
        val low = d.products.filter { it.stock <= it.min }
        if (low.isEmpty()) item { Text(if (bn) "কম স্টকের পণ্য নেই" else "No low-stock products", color = Muted, fontSize = 12.sp) }
        items(low.take(5)) { p -> SimpleRow(p.name, "${p.stock} ${if (bn) "টি বাকি" else "left"}") }
        item { Text(if (bn) "সাম্প্রতিক বিক্রি" else "Recent Sales", color = Navy, fontWeight = FontWeight.Bold) }
        items(d.sales.take(4)) { s -> SimpleRow("${s.customer} • ACS-${s.id.toString().padStart(5,'0')}", money(s.total)) }
    }
}

@Composable
fun PosScreen(d: StoreData, bn: Boolean, onSave: (Sale)->Unit) {
    var customer by remember { mutableStateOf("") }; var mobile by remember { mutableStateOf("") }
    var selectedId by remember { mutableStateOf<Long?>(null) }; var qtyText by remember { mutableStateOf("1") }
    var discountText by remember { mutableStateOf("0") }; var paidText by remember { mutableStateOf("") }
    var cart by remember { mutableStateOf(listOf<Line>()) }; var error by remember { mutableStateOf("") }
    val subtotal = cart.sumOf { it.total }; val discount = discountText.toDoubleOrNull() ?: 0.0
    val total = (subtotal - discount).coerceAtLeast(0.0); val paid = paidText.toDoubleOrNull() ?: 0.0
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item { Text(if (bn) "নতুন বিক্রির মেমো" else "New Sales Memo", color = Navy, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        item { Text("${if (bn) "মেমো নম্বর" else "Memo No."}: ACS-${d.nextId.toString().padStart(5,'0')}   •   ${today()}", color = Green, fontWeight = FontWeight.Bold) }
        item { Field(if (bn) "কাস্টমারের নাম *" else "Customer name *", customer, { customer = it }) }
        item { Field(if (bn) "মোবাইল নম্বর" else "Mobile number", mobile, { mobile = it }, keyboard = KeyboardType.Phone) }
        item { Text(if (bn) "পণ্য নির্বাচন" else "Select Product", color = Navy, fontWeight = FontWeight.Bold) }
        item {
            var expanded by remember { mutableStateOf(false) }
            val selected = d.products.firstOrNull { it.id == selectedId }
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                OutlinedTextField(value = selected?.let { "${it.name} • Stock ${it.stock} • ${money(it.sell)}" } ?: if (bn) "পণ্য বাছাই করুন" else "Choose a product",
                    onValueChange = {}, readOnly = true, modifier = Modifier.menuAnchor().fillMaxWidth(), label = { Text(if (bn) "পণ্য" else "Product") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
                ExposedDropdownMenu(expanded, { expanded = false }) {
                    d.products.forEach { p -> DropdownMenuItem(text = { Text("${p.name} • ${p.stock} pcs • ${money(p.sell)}") }, onClick = { selectedId = p.id; expanded = false }) }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(if (bn) "পরিমাণ" else "Qty", qtyText, { qtyText = it }, Modifier.weight(1f), KeyboardType.Number)
                Button(onClick = {
                    val p = d.products.firstOrNull { it.id == selectedId }; val q = qtyText.toIntOrNull() ?: 0
                    if (p == null || q <= 0) error = if (bn) "পণ্য ও সঠিক পরিমাণ দিন" else "Choose product and valid quantity"
                    else if (q > p.stock) error = if (bn) "স্টকে পর্যাপ্ত পণ্য নেই" else "Insufficient stock"
                    else {
                        val existing = cart.sumOf { if (it.productId == p.id) it.qty else 0 }
                        if (existing + q > p.stock) error = if (bn) "কার্টের পরিমাণ স্টকের বেশি" else "Cart quantity exceeds stock"
                        else { cart = cart + Line(p.id, p.name, q, p.sell, p.buy); selectedId = null; qtyText = "1"; error = "" }
                    }
                }) { Icon(Icons.Default.Add, null); Text(if (bn) "যোগ" else "Add") }
            }
        }
        items(cart) { line -> SimpleRow("${line.name} × ${line.qty}", money(line.total)) }
        item { Text("${if (bn) "সাবটোটাল" else "Subtotal"}: ${money(subtotal)}", color = Navy, fontWeight = FontWeight.SemiBold) }
        item { Field(if (bn) "ছাড় (৳)" else "Discount (৳)", discountText, { discountText = it }, keyboard = KeyboardType.Decimal) }
        item { Text("${if (bn) "সর্বমোট" else "Grand Total"}: ${money(total)}", color = Green, fontWeight = FontWeight.Bold, fontSize = 19.sp) }
        item { Field(if (bn) "জমা টাকা (৳)" else "Received (৳)", paidText, { paidText = it }, keyboard = KeyboardType.Decimal) }
        item { Text("${if (bn) "বাকি" else "Due"}: ${money((total-paid).coerceAtLeast(0.0))}", color = Navy, fontWeight = FontWeight.Bold) }
        item { if (error.isNotBlank()) Text(error, color = Color.Red, fontSize = 12.sp) }
        item { Button(onClick = {
            when {
                customer.isBlank() -> error = if (bn) "কাস্টমারের নাম লিখুন" else "Enter customer name"
                cart.isEmpty() -> error = if (bn) "কমপক্ষে একটি পণ্য যোগ করুন" else "Add at least one product"
                discount < 0 || discount > subtotal -> error = if (bn) "ছাড়ের পরিমাণ যাচাই করুন" else "Check discount amount"
                paid < 0 || paid > total -> error = if (bn) "জমার পরিমাণ যাচাই করুন" else "Check received amount"
                else -> onSave(Sale(d.nextId, today(), customer.trim(), mobile.trim(), cart, discount, paid))
            }
        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Save, null); Text(if (bn) "মেমো সেভ করুন" else "Save Memo") } }
        item { Text(if (bn) "মেমো সেভ হলে স্টক স্বয়ংক্রিয়ভাবে কমবে। পণ্য আগে পণ্য তালিকায় যোগ করুন।" else "Saving a memo automatically deducts stock. Add products in the Products tab first.", color = Muted, fontSize = 10.sp) }
    }
}

@Composable
fun ProductsScreen(d: StoreData, bn: Boolean, onAdd: (Product)->Unit, onUpdate: (Product)->Unit) {
    var name by remember { mutableStateOf("") }; var category by remember { mutableStateOf("Cycle") }
    var buy by remember { mutableStateOf("") }; var sell by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("0") }; var min by remember { mutableStateOf("2") }; var error by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        item { Text(if (bn) "পণ্য ও স্টক" else "Products & Stock", color = Navy, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        item { Text(if (bn) "নতুন পণ্য যোগ" else "Add New Product", color = Navy, fontWeight = FontWeight.Bold) }
        item { Field(if (bn) "পণ্যের নাম" else "Product name", name, { name = it }) }
        item { Field(if (bn) "ক্যাটাগরি" else "Category", category, { category = it }) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field(if (bn) "ক্রয়মূল্য" else "Buy price", buy, { buy = it }, Modifier.weight(1f), KeyboardType.Decimal)
            Field(if (bn) "বিক্রয়মূল্য" else "Sale price", sell, { sell = it }, Modifier.weight(1f), KeyboardType.Decimal)
        } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Field(if (bn) "প্রারম্ভিক স্টক" else "Opening stock", stock, { stock = it }, Modifier.weight(1f), KeyboardType.Number)
            Field(if (bn) "সতর্কতা সীমা" else "Low stock limit", min, { min = it }, Modifier.weight(1f), KeyboardType.Number)
        } }
        item { if (error.isNotBlank()) Text(error, color = Color.Red) }
        item { Button(onClick = {
            val b = buy.toDoubleOrNull(); val s = sell.toDoubleOrNull(); val st = stock.toIntOrNull(); val mn = min.toIntOrNull()
            if (name.isBlank() || b == null || s == null || st == null || mn == null || b < 0 || s < 0 || st < 0 || mn < 0) error = if (bn) "সব তথ্য সঠিকভাবে দিন" else "Enter valid product details"
            else { onAdd(Product(d.nextId, name.trim(), category.trim(), b, s, st, mn)); name=""; buy=""; sell=""; stock="0"; min="2"; error="" }
        }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text(if (bn) "পণ্য সংরক্ষণ" else "Save Product") } }
        item { Divider(); Text("${if (bn) "পণ্যের তালিকা" else "Product List"} (${d.products.size})", color = Navy, fontWeight = FontWeight.Bold) }
        items(d.products) { p ->
            var addQty by remember(p.id) { mutableStateOf("0") }
            Surface(color = Color.White, shape = RoundedCornerShape(13.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(p.name, color = Navy, fontWeight = FontWeight.Bold)
                    Text("${p.category} • Buy ${money(p.buy)} • Sell ${money(p.sell)} • Stock ${p.stock}", color = Muted, fontSize = 11.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (p.stock <= p.min) (if (bn) "কম স্টক" else "LOW STOCK") else (if (bn) "স্টক ঠিক আছে" else "IN STOCK"), color = if (p.stock <= p.min) Color(0xFFB36B20) else Green, fontSize = 10.sp, modifier = Modifier.weight(1f))
                        OutlinedTextField(addQty, { addQty = it }, modifier = Modifier.width(90.dp), label = { Text(if (bn) "স্টক +" else "Add qty") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                        IconButton(onClick = { val q = addQty.toIntOrNull() ?: 0; if (q > 0) { onUpdate(p.copy(stock = p.stock + q)); addQty = "0" } }) { Icon(Icons.Default.AddCircle, null, tint = Green) }
                    }
                }
            }
        }
    }
}

@Composable
fun MoreScreen(d: StoreData, bn: Boolean, onPurchase: (Triple<Long,Int,Purchase>)->Unit, onCollection: (Collection)->Unit, onExpense: (Expense)->Unit, onBackup: ()->Unit, onPdf: (Sale)->Unit) {
    var page by remember { mutableStateOf("menu") }
    Column(Modifier.fillMaxSize()) {
        if (page == "menu") {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item { Text(if (bn) "আরও মডিউল" else "More Modules", color = Navy, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
                item { MenuButton(if (bn) "ক্রয় / স্টক যোগ" else "Purchases", Icons.Default.ShoppingCart) { page = "purchase" } }
                item { MenuButton(if (bn) "কাস্টমারের বাকি আদায়" else "Customer Collection", Icons.Default.Payments) { page = "collection" } }
                item { MenuButton(if (bn) "খরচ যোগ" else "Expenses", Icons.Default.Receipt) { page = "expense" } }
                item { MenuButton(if (bn) "রিপোর্ট ও কাস্টমার পাওনা" else "Reports & Customer Dues", Icons.Default.BarChart) { page = "reports" } }
                item { MenuButton(if (bn) "মেমো PDF শেয়ার" else "Share Memo PDF", Icons.Default.PictureAsPdf) { page = "pdf" } }
                item { MenuButton(if (bn) "ডাটা ব্যাকআপ শেয়ার" else "Export Data Backup", Icons.Default.Backup) { onBackup() } }
                item { Text(if (bn) "ব্যাকআপ ফাইল নিরাপদ স্থানে সংরক্ষণ করুন। Google Drive-এ ম্যানুয়ালি আপলোড করতে পারবেন।" else "Keep backup files safely. You can upload them to Google Drive manually.", color = Muted, fontSize = 10.sp) }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal=14.dp, vertical=8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { page = "menu" }) { Icon(Icons.Default.ArrowBack, null) }
                Text(when(page) { "purchase" -> if(bn) "ক্রয় এন্ট্রি" else "Purchase Entry"; "collection" -> if(bn) "বাকি আদায়" else "Due Collection"; "expense" -> if(bn) "খরচ এন্ট্রি" else "Expense Entry"; "reports" -> if(bn) "রিপোর্ট" else "Reports"; else -> if(bn) "মেমো PDF" else "Memo PDF" }, color=Navy, fontWeight=FontWeight.Bold, fontSize=20.sp)
            }
            when(page) {
                "purchase" -> PurchaseForm(d,bn,onPurchase)
                "collection" -> CollectionForm(d,bn,onCollection)
                "expense" -> ExpenseForm(bn,onExpense)
                "reports" -> ReportsScreen(d,bn)
                "pdf" -> LazyColumn(contentPadding=PaddingValues(14.dp)) { items(d.sales) { s -> SimpleRow("${s.customer} • ACS-${s.id}", money(s.total)); TextButton(onClick={onPdf(s)}) { Text(if(bn) "PDF শেয়ার" else "Share PDF") } } }
            }
        }
    }
}

@Composable
fun PurchaseForm(d: StoreData,bn:Boolean,onSave:(Triple<Long,Int,Purchase>)->Unit) {
    var selected by remember { mutableStateOf<Long?>(null) }; var qty by remember { mutableStateOf("1") }; var supplier by remember { mutableStateOf("") }; var paid by remember { mutableStateOf("") }; var cost by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }; var error by remember { mutableStateOf("") }
    val p=d.products.firstOrNull{it.id==selected}
    LazyColumn(contentPadding=PaddingValues(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
        item { var open by remember { mutableStateOf(false) }; ExposedDropdownMenuBox(open,{open=!open}) {
            OutlinedTextField(p?.name ?: if(bn) "পণ্য বাছাই করুন" else "Choose product",{},readOnly=true,modifier=Modifier.menuAnchor().fillMaxWidth(),label={Text(if(bn)"পণ্য" else "Product")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(open)})
            ExposedDropdownMenu(open,{open=false}) { d.products.forEach { x -> DropdownMenuItem(text={Text(x.name)},onClick={selected=x.id;cost=x.buy.toString();open=false}) } }
        } }
        item { Field(if(bn)"সাপ্লায়ারের নাম" else "Supplier",supplier,{supplier=it}) }
        item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { Field(if(bn)"পরিমাণ" else "Quantity",qty,{qty=it},Modifier.weight(1f),KeyboardType.Number); Field(if(bn)"একক ক্রয়মূল্য" else "Unit cost",cost,{cost=it},Modifier.weight(1f),KeyboardType.Decimal) } }
        item { Field(if(bn)"পরিশোধ" else "Paid",paid,{paid=it},keyboard=KeyboardType.Decimal) }
        item { Field(if(bn)"নোট" else "Note",note,{note=it}) }
        item { if(error.isNotBlank()) Text(error,color=Color.Red) }
        item { Button(onClick={
            val q=qty.toIntOrNull()?:0; val c=cost.toDoubleOrNull(); val pay=paid.toDoubleOrNull()?:0.0; val total=q*(c?:0.0)
            if(p==null||q<=0||c==null||c<0||pay<0||pay>total) error=if(bn)"তথ্য যাচাই করুন" else "Check purchase details"
            else onSave(Triple(p.id,q,Purchase(today(),supplier,total,pay,note)))
        },modifier=Modifier.fillMaxWidth()){Text(if(bn)"ক্রয় সেভ ও স্টক যোগ" else "Save Purchase & Add Stock")} }
        item { Text(if(bn)"ক্রয়ের মোট" else "Purchase total",color=Muted); Text(money((qty.toIntOrNull()?:0)*(cost.toDoubleOrNull()?:0.0)),color=Navy,fontWeight=FontWeight.Bold) }
    }
}

@Composable
fun CollectionForm(d:StoreData,bn:Boolean,onSave:(Collection)->Unit) {
    val dues=customerDues(d)
    var customer by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }; var error by remember { mutableStateOf("") }
    LazyColumn(contentPadding=PaddingValues(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
        item { Text(if(bn)"কাস্টমারের বাকি তালিকা" else "Customer Outstanding",color=Navy,fontWeight=FontWeight.Bold) }
        items(dues.toList().filter{it.second>0.0}) { (name,due) -> TextButton(onClick={customer=name}) { Text("$name — ${money(due)}") } }
        item { Field(if(bn)"কাস্টমারের নাম" else "Customer name",customer,{customer=it}) }
        item { Field(if(bn)"জমার পরিমাণ (৳)" else "Amount received (৳)",amount,{amount=it},keyboard=KeyboardType.Decimal) }
        item { Field(if(bn)"নোট" else "Note",note,{note=it}) }
        item { if(error.isNotBlank()) Text(error,color=Color.Red) }
        item { Button(onClick={
            val a=amount.toDoubleOrNull()?:0.0; val due=dues[customer]?:0.0
            if(customer.isBlank()||a<=0||a>due) error=if(bn)"নাম/পরিমাণ বা পাওনা যাচাই করুন" else "Check customer, amount and outstanding"
            else onSave(Collection(today(),customer.trim(),a,note))
        },modifier=Modifier.fillMaxWidth()){Text(if(bn)"জমা সেভ করুন" else "Save Collection")} }
    }
}

@Composable
fun ExpenseForm(bn:Boolean,onSave:(Expense)->Unit) {
    var category by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }; var error by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Field(if(bn)"খরচের খাত" else "Expense category",category,{category=it})
        Field(if(bn)"টাকার পরিমাণ" else "Amount",amount,{amount=it},keyboard=KeyboardType.Decimal)
        Field(if(bn)"বিস্তারিত" else "Details",note,{note=it})
        if(error.isNotBlank()) Text(error,color=Color.Red)
        Button(onClick={val a=amount.toDoubleOrNull()?:0.0;if(category.isBlank()||a<=0)error=if(bn)"খাত ও সঠিক টাকা দিন" else "Enter category and valid amount" else onSave(Expense(today(),category,a,note))},modifier=Modifier.fillMaxWidth()){Text(if(bn)"খরচ সেভ করুন" else "Save Expense")}
    }
}

@Composable
fun ReportsScreen(d:StoreData,bn:Boolean) {
    val dues=customerDues(d)
    val sales=d.sales.sumOf{it.total}; val cogs=d.sales.sumOf{s->s.lines.sumOf{it.qty*it.cost}}
    val gross=sales-cogs; val expenses=d.expenses.sumOf{it.amount}; val cash=d.sales.sumOf{it.paid}+d.collections.sumOf{it.amount}-d.purchases.sumOf{it.paid}-expenses
    LazyColumn(contentPadding=PaddingValues(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
        item { ReportLine(if(bn)"মোট বিক্রি" else "Total Sales",money(sales)) }
        item { ReportLine(if(bn)"বিক্রিত পণ্যের ক্রয়মূল্য" else "Cost of Goods Sold",money(cogs)) }
        item { ReportLine(if(bn)"মোট লাভ (গ্রস)" else "Gross Profit",money(gross)) }
        item { ReportLine(if(bn)"মোট খরচ" else "Expenses",money(expenses)) }
        item { ReportLine(if(bn)"নিট লাভ (আনুমানিক)" else "Net Profit (estimate)",money(gross-expenses)) }
        item { ReportLine(if(bn)"ক্যাশ ব্যালেন্স" else "Cash Balance",money(cash)) }
        item { ReportLine(if(bn)"মোট পাওনা" else "Total Receivables",money(dues.values.sum())) }
        item { Text(if(bn)"কাস্টমারভিত্তিক পাওনা" else "Customer-wise Receivables",color=Navy,fontWeight=FontWeight.Bold) }
        items(dues.toList().filter{it.second>0.0}.sortedByDescending{it.second}) { (name,due)->SimpleRow(name,money(due)) }
        item { Text(if(bn)"এই রিপোর্ট সব সময়ের মোট হিসাব; তারিখভিত্তিক ফিল্টার পরবর্তী সংস্করণে যোগ হবে।" else "This is an all-time summary; date filters are planned for a later version.",color=Muted,fontSize=10.sp) }
    }
}

fun customerDues(d:StoreData): Map<String,Double> {
    val map=mutableMapOf<String,Double>()
    d.sales.forEach{map[it.customer]=(map[it.customer]?:0.0)+it.due}
    d.collections.forEach{map[it.customer]=(map[it.customer]?:0.0)-it.amount}
    return map.mapValues{it.value.coerceAtLeast(0.0)}
}

@Composable fun Field(label:String,value:String,onChange:(String)->Unit,modifier:Modifier=Modifier,keyboard:KeyboardType=KeyboardType.Text) {
    OutlinedTextField(value,onChange,modifier=modifier.fillMaxWidth(),label={Text(label,fontSize=12.sp)},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=keyboard),shape=RoundedCornerShape(12.dp))
}
@Composable fun Metric(title:String,value:String,icon:androidx.compose.ui.graphics.vector.ImageVector,modifier:Modifier) {
    Surface(color=Color.White,shape=RoundedCornerShape(16.dp),modifier=modifier){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Icon(icon,null,tint=Green);Text(title,color=Muted,fontSize=10.sp);Text(value,color=Navy,fontWeight=FontWeight.Bold,fontSize=16.sp)}}
}
@Composable fun SimpleRow(left:String,right:String) {
    Surface(color=Color.White,shape=RoundedCornerShape(12.dp),modifier=Modifier.fillMaxWidth()){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Text(left,color=Navy,fontSize=12.sp,modifier=Modifier.weight(1f));Text(right,color=Navy,fontWeight=FontWeight.SemiBold,fontSize=12.sp)}}
}
@Composable fun ReportLine(label:String,value:String){SimpleRow(label,value)}
@Composable fun MenuButton(label:String,icon:androidx.compose.ui.graphics.vector.ImageVector,onClick:()->Unit){Surface(color=Color.White,shape=RoundedCornerShape(13.dp),modifier=Modifier.fillMaxWidth()){TextButton(onClick=onClick,modifier=Modifier.fillMaxWidth().padding(5.dp)){Icon(icon,null,tint=Green);Spacer(Modifier.width(10.dp));Text(label,color=Navy);Spacer(Modifier.weight(1f));Icon(Icons.Default.ChevronRight,null)}}}

private fun saveData(ctx:Context,d:StoreData) {
    val root=JSONObject().put("nextId",d.nextId)
    fun linesJson(lines:List<Line>):JSONArray { val a=JSONArray(); lines.forEach{a.put(JSONObject().put("pid",it.productId).put("name",it.name).put("qty",it.qty).put("price",it.price).put("cost",it.cost))};return a }
    root.put("products",JSONArray().also{a->d.products.forEach{a.put(JSONObject().put("id",it.id).put("name",it.name).put("category",it.category).put("buy",it.buy).put("sell",it.sell).put("stock",it.stock).put("min",it.min))}})
    root.put("sales",JSONArray().also{a->d.sales.forEach{a.put(JSONObject().put("id",it.id).put("date",it.date).put("customer",it.customer).put("mobile",it.mobile).put("discount",it.discount).put("paid",it.paid).put("lines",linesJson(it.lines)))}})
    root.put("purchases",JSONArray().also{a->d.purchases.forEach{a.put(JSONObject().put("date",it.date).put("supplier",it.supplier).put("total",it.total).put("paid",it.paid).put("note",it.note))}})
    root.put("collections",JSONArray().also{a->d.collections.forEach{a.put(JSONObject().put("date",it.date).put("customer",it.customer).put("amount",it.amount).put("note",it.note))}})
    root.put("expenses",JSONArray().also{a->d.expenses.forEach{a.put(JSONObject().put("date",it.date).put("category",it.category).put("amount",it.amount).put("note",it.note))}})
    ctx.getSharedPreferences("asha_store_v3",Context.MODE_PRIVATE).edit().putString("data",root.toString()).apply()
}
private fun loadData(ctx:Context):StoreData=try {
    val r=JSONObject(ctx.getSharedPreferences("asha_store_v3",Context.MODE_PRIVATE).getString("data","{}")!!)
    fun arr(k:String)=r.optJSONArray(k)?:JSONArray()
    val products=(0 until arr("products").length()).map{val o=arr("products").getJSONObject(it);Product(o.getLong("id"),o.getString("name"),o.optString("category"),o.getDouble("buy"),o.getDouble("sell"),o.getInt("stock"),o.getInt("min"))}
    val sales=(0 until arr("sales").length()).map{val o=arr("sales").getJSONObject(it);val a=o.getJSONArray("lines");val ls=(0 until a.length()).map{val x=a.getJSONObject(it);Line(x.getLong("pid"),x.getString("name"),x.getInt("qty"),x.getDouble("price"),x.getDouble("cost"))};Sale(o.getLong("id"),o.getString("date"),o.getString("customer"),o.optString("mobile"),ls,o.getDouble("discount"),o.getDouble("paid"))}
    val purchases=(0 until arr("purchases").length()).map{val o=arr("purchases").getJSONObject(it);Purchase(o.getString("date"),o.optString("supplier"),o.getDouble("total"),o.getDouble("paid"),o.optString("note"))}
    val collections=(0 until arr("collections").length()).map{val o=arr("collections").getJSONObject(it);Collection(o.getString("date"),o.getString("customer"),o.getDouble("amount"),o.optString("note"))}
    val expenses=(0 until arr("expenses").length()).map{val o=arr("expenses").getJSONObject(it);Expense(o.getString("date"),o.getString("category"),o.getDouble("amount"),o.optString("note"))}
    StoreData(products,sales,purchases,collections,expenses,r.optLong("nextId",1))
}catch(_:Exception){StoreData()}

private fun shareBackup(ctx:Context,d:StoreData) {
    val raw=ctx.getSharedPreferences("asha_store_v3",Context.MODE_PRIVATE).getString("data","{}") ?: "{}"
    val f=File(ctx.cacheDir,"AshaCycleStore_Backup_${today().replace("-","")}.json")
    f.writeText(raw)
    val uri=FileProvider.getUriForFile(ctx,"${ctx.packageName}.provider",f)
    val i=Intent(Intent.ACTION_SEND).apply{type="application/json";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)}
    ctx.startActivity(Intent.createChooser(i,"Share Asha Cycle Store Backup"))
}
private fun shareMemoPdf(ctx:Context,s:Sale) {
    val doc=PdfDocument();val info=PdfDocument.PageInfo.Builder(595,842,1).create();val page=doc.startPage(info);val c=page.canvas
    val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.rgb(20,40,63);textSize=22f;typeface=android.graphics.Typeface.DEFAULT_BOLD}
    c.drawText("ASHA CYCLE STORE",40f,55f,p);p.textSize=11f;p.typeface=android.graphics.Typeface.DEFAULT
    c.drawText("Nimitala Fakir Para, Chapai Nawabganj",40f,76f,p);c.drawText("Memo: ACS-${s.id.toString().padStart(5,'0')}     Date: ${s.date}",40f,108f,p)
    c.drawText("Customer: ${s.customer}",40f,130f,p);c.drawText("Mobile: ${s.mobile.ifBlank{"-"}}",40f,150f,p)
    c.drawText("Product",40f,190f,p);c.drawText("Qty",340f,190f,p);c.drawText("Price",400f,190f,p);c.drawText("Total",490f,190f,p)
    var y=215f;s.lines.forEach{l->c.drawText(l.name.take(38),40f,y,p);c.drawText(l.qty.toString(),340f,y,p);c.drawText(String.format(Locale.US,"%.2f",l.price),400f,y,p);c.drawText(String.format(Locale.US,"%.2f",l.total),490f,y,p);y+=22f}
    y+=25f;c.drawText("Subtotal: ${money(s.subtotal)}",360f,y,p);y+=20;c.drawText("Discount: ${money(s.discount)}",360f,y,p);y+=20;c.drawText("Total: ${money(s.total)}",360f,y,p);y+=20;c.drawText("Received: ${money(s.paid)}",360f,y,p);y+=20;c.drawText("Due: ${money(s.due)}",360f,y,p)
    c.drawText("Thank you for shopping with us.",40f,790f,p);doc.finishPage(page)
    val dir=File(ctx.cacheDir,"memos").apply{mkdirs()};val f=File(dir,"ACS-${s.id}.pdf");f.outputStream().use{doc.writeTo(it)};doc.close()
    val uri=FileProvider.getUriForFile(ctx,"${ctx.packageName}.provider",f)
    val i=Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)}
    ctx.startActivity(Intent.createChooser(i,"Share Memo PDF"))
}
